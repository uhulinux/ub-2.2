
b o o s t  V I I I   V 2 . 0
-------------------------------------------------

boost again... the winamp 2.0 version, made for
your winamp pleasure...

i also wanted to include some modified plugin,
either funkyfx or the good old speaker plug, but
i decided that this can wait a while.

i also hope that i will keep my skinning addiction
calm for a while, gotta do other things too... 
i dug my nose so near to my 17' monitor at 800x600,
that i really could have given every pixel a name.

skins from misery in motion
--------------------------------------------------

miseryamp 		1.0
phreak 		0.667
xtended 		1.0
stainless 		1.0
metropolis		1.0
metropolis 		2.01 *	
pandemonium		1.0
coldbringer		1.0
coldbringer		2.01 *
boost VIII		1.0
boost VIII		2.0 *

* winamp 2.0 support

distibute this skin freely, but don't delete the 
readme. manipulators and modifiers of this skin 
will be eaten by myself personally :-0.

-------------------------------------------------
misery ,09.10.98

web: 	http://members.tripod.com/~misery_in_motion
mail:	misery_in_motion@hotmail.com

(c) m i s e r y   i n   m o t i o n   ( 9 8 ) 