           ...[[::: S-Ryzer :::]]...
                   ---------
Skin name         = S-Ryzer
Skin author       = Snecx Tan Wei Heng
Email             = snecx@yahoo.com
Website           = http://snecx.cjb.net/
Component skinned = Main
                    Equalizer
                    Playlist
                    MiniBrowser   - ( For those  )
                    winampmb.htm  - ( who use MB )
Skin notes        = This is a skin that made by Photoshop without
                    using any filters except 'blur'. The best of
                    my skin that I had made for now.I think that
                    it is really hard for me to make a better than
                    this.

           ...[[::: The End :::]]...
                  ---------