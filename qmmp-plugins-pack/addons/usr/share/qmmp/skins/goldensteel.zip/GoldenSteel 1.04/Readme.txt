GoldenSteel 1.04	by Enemy�	     December 25th 1999

Introduction___________________________________________________

	Thank you for downloading this file.
	This is a WinAmp 2.x skin, modified from the Indiglow
Steel skin from Death Angel.

Information____________________________________________________

	I copied (In fact, changed colors from) Indiglow Steel
because I believe this is one of the best I've ever seen. (And
don't subestimate me, I used to have more than 400 skins).

Installation___________________________________________________

	Unzipping to your winamp/skins directory will create a
subfolder storing all data. Launch Winamp, go to the option
menu and use the skin-browser to select the skin.

	For users of Winamp 2.04 or higher it's enough to copy
the ZIP-File to the winamp/skins directory.

Preset for the wVis plug-in____________________________________

	WinAmp v2.0x (until 2.09) comes with the nice wVis
plug-in and therefore I threw in a preset especially made for
this skin. To install it press CTRL-K to select the wVis
plug-in, then right-click the plug-in window which pops up and
preset->load my preset from the GoldenSteel Skin directory
wherever you put it. This should bring up some nice effects!
I think it looks really great docked as "Little Vis w/o time".

Author Notes:__________________________________________________

	This is my forth attempt in doing a WinAmp Skin. And I
still have hope of doing a groundbreaking skin. Any suggestions
email-me.
	If you like this skin, download the original one too!
And, if possible, copy my other skins too (at Skinz.org).

History________________________________________________________

1.0	First version (not released)
1.01	Changed the minibrowser (the slider didn't fit well).
	(not release too)
1.02	By suggestion of my friend Davi, changed the BG color.
1.03	Modified ShufRep.bmp in order to show "RANDOM" instead
	 of "ROM", now "REP" has true pressed look.
	Together to this updates, I reduced its size too.
1.04	Updated EasterEgg and Readme to show the real author.
	New size reduction.
	Changed the nickname

Data File______________________________________________________

Designed in: PSP 5.01
Best viewed using: 16 bit High Color
Approximate colours count: 500

Created during June '99 by:____________________________________

Enemy� (Rubens Haruo Eishima)
Taboao da Serra, Brazil
E-Mail: eishima@writeme.com
URL: http://pagina.de/rubens	(Portuguese)
	http://members.xoom.com/RH_Eishima/
ICQ: 26160822

Legal__________________________________________________________

Winamp is Copyright � 1997-1998 Nullsoft, Inc. and Justin
Frankel.
Winamp is a trademark of Nullsoft, Inc.

--== Distribute this skin freely, but do not change it. ==--