Ergo created for QMMP project by Andrey Andreev
andreev00@gmail.com