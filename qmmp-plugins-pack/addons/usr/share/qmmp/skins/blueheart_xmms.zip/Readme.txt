SKIN NAME: blueHeart XMMS
SKIN VERSION: 1.0
DATE CREATED: 11 October, 1999
SKIN DESIGNERS: JazzMidi & Alf
EMAILS: jazzmidi@mindspring.com
        ried@si.tn.tudelft.nl
SKIN GRAPHICS BY: hOax a.k.a Chris Fofiu
EMAIL: cfofiu@mindspring.com
URL: http://www.mindspring.com/~cfofiu/e
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
SKIN NOTES:
Skin should be used with Enlightenment theme
called blueHeart by hOax
visit http://e.themes.org

DESIGNER NOTES:
This skin was inspired by the Enlightenment
Theme called blueHeart. One of the best
blue e-themes for enlightenment.
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
ACKNOWLEDGEMENTS:

To hOax - for creating a great blue Etheme.

To - all the people who created and improved
the GIMP :-)

To Xmms crew - thank you for making a wonderful
mp3 player. Keep up the great work.

To the enlightenment crew - you guys are the best.
Thanks and keep improving e. Looking good!

To You - thank you for downloading our skin.

Enjoy using this skin!
JazzMidi
Jazz Alley XG Midis
jazzmidi@mindspring.com
Alf
ried@si.tn.tudelft.nl
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
CHANGE LOG:
V1.0
- First Release
