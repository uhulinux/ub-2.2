++ The  Pordey's  skins  ++

// Display...
recommend 16bit color or higher.

Visit my homepage to find the other skins that I made.
Now available:

Winamp 2.xx Skins:

Black combo
9953r
9953b
Pordey AMP 02
Pordey AMP Illuminator
Freuch
Gray
PR700K
D1000
BK8700
Pioneer MP3800s
Pioneer KEM P6300r
BK8500lcd
BK8500b
Onkyo Gold

// installation...
unzip into your Winamp skins folder.(ex. c:\program files\winamp\Skins\ )
load up winamp and popup the window;'Skin Browser'(=press 'Alt'+'S'),
select 'Pordey Skin'.



Sonique 1.xx Skins:

Z-768
metaLINK 
metaLINK used
Pino
Beetle Standard
Beetle (blue)
Beetle (green)
Beetle Silver Special
Beetle Gold Edition
Flat LCD
Nautilus

// installation...
unzip into your Sonique skins folder.(ex. c:\program files\sonique\Skins\ )
load up sonique, go to setup options;'Skins'(=press 'UP' & 'DOWN'),
select 'Pordey Skin'.

// Contact...
Check Pordey " ICQ 17576280
E-mail. : ppardi@planet.it
Web Site: http://www.mp3-2000.com/pordey/
Thank's for your downloading.


(c)1999 Pordey.