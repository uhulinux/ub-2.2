888b     d888                   888               
8888b   d8888                   888               
88888b.d88888                   888               
888Y88888P888  .d88b.   .d8888b 888  888  .d88b.  
888 Y888P 888 d8P  Y8b d88P"    888 .88P d88""88b 
888  Y8P  888 88888888 888      888888K  888  888 
888   "   888 Y8b.     Y88b.    888 "88b Y88..88P 
888       888  "Y8888   "Y8888P 888  888  "Y88P"  
_________________________________________________
-------------------------------------------------
- - - - - - - - - - - - - - - - - - - - - - - - -

Mecko - 1999. by $teven

 This is a funky skin. I was not sure on the stlye
of the skin. I was more concerned with the colors.
I wanted to make a green and yellow skin. And so
here it is. It looks kinda like Xtinction T-10. So
Thats means it is not Xtinct after all. Kinda
ironic.

=)

http://www.shoggot.com/

steven@shoggot.com