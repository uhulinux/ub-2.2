
- Ampesizer Standard 2
-
- a skin for WinAMP 2.0 or higher. Includes Playlist and EQ skins.
-
- version 1.0 - 22.01.99
-
- by Eduardo Sousa - edsousa@esoterica.pt
-
- Original by MATDesign - http://www.matdesign.demon.nl/skins.htm


The Ampesizer series are my favourite skins, and I found it really 
strange that the Standard version didn't have a WinAMP 2.0 update.

So I got to work and I made the update, adding EQ and Playlist skins
and making other corrections.

Full credit to MATDesign for the original Ampesizer Standard skin, it 
is really one of my favourites.

Enjoy!

- Eduardo Sousa - http://rents.cjb.net


Installation
------------
1. Copy or move sizer-st2.zip to the WinAmp Skins directory. 
2. Unzip the file to generate the 'sizer-st2' directory and 
   necessary files for the skin.
3. Launch WinAmp, and type Alt-S for the Skin Browser.
4. Double-click on 'sizer-st2'.

NOTE: Some recent versions of WinAmp have .ZIP support, if that's your
      case then just leave the .ZIP file on your Skins directory.