How to use this skin:

If you have a Winamp 2.04 or more:

put this zipfile into the /skins folder
under the /winamp one, then press ALT+S
with WinAmp Running and choose the skin from the list
that will pop up.

If you have a previous version:

Unzip all the zipfile into a folder under /skins one.

i.e.: /winamp/skins/DreamWeaver

Every skin needs to be unzipped in a different folder.

For more informations about this skin see:
DreamWeaver.txt

check for news here:
http://come.to/goranhq
email: goran@tiscalinet.it

