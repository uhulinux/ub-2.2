
s c h u b d u e s e   V 2 . 0
-------------------------------------------------

well, well
this bastard of a skin gave me something to worry
about. normally i need for an average skin from
three days to two weeks, but this one kept me
cursing over a month or so.

the design is something i intend to call (take a
deep breath) 30's & 40's retrofuturedesign, and
it should somehow remind of such things as 1984,
kafka, maybe a little bit orson wells. as it got
finished, it looked more like from dune, but thats
nearly as good.

skins from misery in motion
--------------------------------------------------

miseryamp 		1.0 	(-)
phreak 		0.667
xtended 		1.0
stainless 		1.0
metropolis		1.0
metropolis 		2.01 	(*)	
pandemonium		1.0
coldbringer		1.0
coldbringer		2.01 	(*)
boost VIII		1.0
boost VIII		2.0 	(*)
schubduese		1.0
schubduese		2.0

* winamp 2.0x support
- shitty skin, removed

distibute this skin freely, but don't delete the 
readme. manipulators and modifiers of this skin 
will be eaten by myself personally :-0.

-------------------------------------------------
misery ,10.11.98

web: 	http://members.tripod.com/~misery_in_motion
mail:	misery_in_motion@hotmail.com

(c) m i s e r y   i n   m o t i o n   ( 9 8 ) 