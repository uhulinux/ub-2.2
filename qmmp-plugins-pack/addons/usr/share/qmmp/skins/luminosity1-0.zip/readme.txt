........................................... Zombie '99
------------------------------------------------------
                l u m i n o s i t y               v1.0
......................................................

Author notes:
My second WinAMP v2 Skin. This one includes the 2.10 
update for the browser window (what next - WinAMP OS?),
which is still in beta version - and and a wallpaper 
image to use with the skin (PNG format).

You may distribute this skin freely but please do not 
edit it in any way. If there are any updates to be 
made I'll do them myself. Thanks!

......................................................

Designed in: MS Image Composer 1.5 and PSP 5.00
Best viewed using: 24 bit True Color
Approximate colours count: 617
Y2K status: Compliant
Song: 'Anthem for the year 2000' - Silverchair
Mood: %-)
Date/Time: 27 April 1999, 11:54 PM

Additional files included:
- Luminosity.ffx - settings file for FunkyFX
- Luminosity.vws - presets file for wVis 4.1
- Luminosity.png - wallpaper image (800x600)

......................................................

Created by:
Damien du Toit (Zombie at customize.org & skinz.org)
Cape Town, South Africa
E-Mail: damiendt@icon.co.za
URL: http://damiendt.www.icon.co.za/
ICQ: 2099552
IRC: Stipe on is.zanet.org.za - #5fm, #cape_town, #za

......................................................
"There is nothing like returning to a place that 
remains unchanged to find the ways in which you 
yourself have altered" - Nelson Mandela
......................................................
                                     Happy Freedom Day
......................................................
You are the star tonight.
Your sun electric, outta sight.
Your light eclipsed the moon tonight.
Electrolite. You're outta sight.
......................................................
         Electrolite, R.E.M. (New Adventures in Hi-Fi)
......................................................