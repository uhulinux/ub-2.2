skin Zany-Box copyrighted Deuce �
if I see a skin with ONE of my textures i will personaly do
everything in my power to destroy the lamer who did it.

Comments:
This is the best I've done.
NEVER copy textures from it i WILL get VERY angry