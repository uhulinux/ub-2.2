\_________________/
| CircuitAMP 2.0  |
/-----------------\

 By Ahmed Arebi

 14.4.1999
 
 This is a cool skin for winamp version 2.X it makes you abel to see what there is 
 ander the cover of the winamp.
 
 This winamp skin also includes Play list and Equalizer

 



 Email : a_arebi@hotmail.com