CORETEX'S OFFICIAL WINAMP SKIN
------------------------------
Rules:
Distibute this skin as much as you like as long as you don't delete the readme.txt or change it in any way
DO NOT manipulate or modify this skin in any way
----------------------------
Contact Deuce @:
X_Deuce_X@Hotmail.com
mIRC: EFNet #scene
UIN: 6668121
----------------------------
Find coretex music @:
http://www.traxinspace.com (search for coretex)
http://www.mp3.com/coretex
----------------------------