xj amp no.4  2.0

-----------

if any question, email:alex88@telekbird.com.cn

-----------

Thank you for download my  skin,distribute freely, 
but please don't modify the images. thanks
            
                          -----lihailiang  oct 15,1999