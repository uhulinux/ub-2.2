BMI - HypnoAmp 1.0 for Winamp 2.10+
===================================

How to get this beast running
-----------------------------
1) Download Winamp from http://www.winamp.com
2) Run the downloaded file
3) Locate your Winamp directory (eg. C:\programme\winamp)
   and enter it.
4) Locate the "SKINS" dir inside Winamp dir.
5) Copy the .zip file or unpack manually using WinZIP
   or any other Win32 unzipper to this dir.
6) Launch Winamp
7) Press "ALT+S" and select the "F!_2.10-BMI" entry
8) Click the "Close" Button
9) Done ....

Authors Winamp Settings 01
--------------------------
Vis.Mode          : Analyzer
Analyzer Mode     : vertikal lines, bars and peaks checked
Windowshade VU    : smooth
Refresh Rate      : full
Analyzer falloff  : faster
Peaks falloff     : slowest


Authors Winamp Settings 02
--------------------------
Vis.Mode          : Scope
Scope Mode        : line scope
Windowshade VU    : smooth
Refresh Rate      : full
