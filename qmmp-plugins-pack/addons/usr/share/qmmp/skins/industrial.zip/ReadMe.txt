
Distrubite this skin without this file and I'll hunt you down and kill you.  Kay?

Hey, this skin is a takeoff, not a ripoff, of another skin.  But hey, who cares?
The other one sucked ass.  This one is godly.  See?  Now that it's godly, it's all
OK.  Now we can all go home.

For those that care, this skin is pieced together from: (and me using mspaint)
Main design    - an OLD 'skin' called industrial.  Had crappy everything.
Equalizer      - from Pho2k - but just the sliders.  Hope the author doesn't mind.
Some of the PL - Cold Fusion 2.0.  But just a tiny bit of the PL.
The font       - ColdBringer font, by the godly skin artist, Misery in Motion.

            Please excuse my piracy, but it's worth it, right?

Hope ya like the sin, er...skin.  heheh... feel free to rip this to shit.  Just
send me a copy, if you don't, like I said above, i'll hunt you down, rip out your
little black heart, and eat your children for five generations, alright?  Wait,
that's not what I said.


           "Never underestimate the power of stupid people in large groups"

						- Colin McCann
						  StarkRafter@xoommail.com

