
 . .: :  :   :    :[ crystal-diode, 5.1 ]:    :   :  : :. .
 :
 : author  : sphere(kartoon@beer.com ..icq:2665270)
 : version : five.one
 : webpage : http://ds.ownz.com
 :...
 ..:: [ about ]:  : :. .
 :
 :  : now with everthing skinned that can be for v2.21.
 :  : surface is "harshly used futuristic urinal metal."
 : .: email me with any comments, problems, ect.
 :........................: :: ::: :::: ::: :: :..........................: